package com.example.mochiauto

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.util.Log
import android.view.Surface
import androidx.car.app.AppManager
import androidx.car.app.CarAppService
import androidx.car.app.CarContext
import androidx.car.app.Screen
import androidx.car.app.Session
import androidx.car.app.SurfaceCallback
import androidx.car.app.SurfaceContainer
import androidx.car.app.model.Action
import androidx.car.app.model.ActionStrip
import androidx.car.app.model.Template
import androidx.car.app.navigation.model.NavigationTemplate
import androidx.car.app.validation.HostValidator
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import kotlin.concurrent.thread
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

// ==========================================
// 1. SERVICE & SESSION
// ==========================================

class MochiCarAppService : CarAppService() {
    // Fine for development/sideloading; use a signature allow-list for a store release.
    override fun createHostValidator(): HostValidator = HostValidator.ALLOW_ALL_HOSTS_VALIDATOR
    override fun onCreateSession(): Session = MochiSession()
}

class MochiSession : Session() {
    override fun onCreateScreen(intent: Intent): Screen = MochiScreen(carContext)
}

// ==========================================
// 2. SCREEN, SENSORS, RENDER LOOP
// ==========================================

enum class MochiState { IDLE, ACCELERATING, BRAKING, TURNING_LEFT, TURNING_RIGHT }

class MochiScreen(carContext: CarContext) :
    Screen(carContext), SurfaceCallback, SensorEventListener, DefaultLifecycleObserver {

    @Volatile private var activeSurface: Surface? = null
    @Volatile private var isRunning = false
    private var renderThread: Thread? = null

    @Volatile private var stableArea = Rect()
    @Volatile private var smoothedLatG = 0f
    @Volatile private var smoothedLongG = 0f
    @Volatile private var currentState = MochiState.IDLE

    private val renderer = MochiFaceRenderer()

    // Phone upright in portrait on the dash, screen facing you = true; flat in a tray = false.
    private val isPhoneMountedUpright = true

    private val sensorManager = carContext.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private var activeSensor: Sensor? = null
    private var usingFallback = false

    // Gravity estimate for the raw-accelerometer fallback
    private val grav = FloatArray(3)
    private var gravSeeded = false

    private val filterAlpha = 0.15f

    private val enterBrake = -3.5f
    private val exitBrake = -2.0f
    private val enterAccel = 2.5f
    private val exitAccel = 1.5f
    private val enterTurn = 2.5f
    private val exitTurn = 1.5f

    init {
        lifecycle.addObserver(this)
        carContext.getCarService(AppManager::class.java).setSurfaceCallback(this)

        val linear = sensorManager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION)
        if (linear != null) {
            activeSensor = linear
        } else {
            activeSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
            usingFallback = true
        }
    }

    override fun onGetTemplate(): Template {
        val exit = Action.Builder()
            .setTitle("Exit")
            .setOnClickListener { carContext.finishCarApp() }
            .build()
        return NavigationTemplate.Builder()
            .setActionStrip(ActionStrip.Builder().addAction(exit).build())
            .build()
    }

    // ---- SurfaceCallback ----

    override fun onSurfaceAvailable(surfaceContainer: SurfaceContainer) {
        activeSurface = surfaceContainer.surface
        if (surfaceContainer.width > 0 && surfaceContainer.height > 0) {
            stableArea = Rect(0, 0, surfaceContainer.width, surfaceContainer.height)
        }
        startRenderThread()
    }

    override fun onStableAreaChanged(stableArea: Rect) {
        if (!stableArea.isEmpty) this.stableArea = Rect(stableArea)
    }

    override fun onVisibleAreaChanged(visibleArea: Rect) { /* ignored on purpose */ }

    override fun onSurfaceDestroyed(surfaceContainer: SurfaceContainer) {
        stopRenderThread()
        activeSurface = null
    }

    // ---- Lifecycle ----

    override fun onStart(owner: LifecycleOwner) {
        // Fresh start: drop stale filter state so we don't resume mid-"braking"
        smoothedLatG = 0f
        smoothedLongG = 0f
        currentState = MochiState.IDLE
        gravSeeded = false
        activeSensor?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
    }

    override fun onStop(owner: LifecycleOwner) {
        sensorManager.unregisterListener(this)
    }

    override fun onDestroy(owner: LifecycleOwner) {
        carContext.getCarService(AppManager::class.java).setSurfaceCallback(null)
        stopRenderThread()
    }

    // ---- Render thread ----

    private fun startRenderThread() {
        if (isRunning) return
        isRunning = true

        renderThread = thread(name = "MochiRenderThread") {
            val frameNs = 16_666_666L
            var lastNs = System.nanoTime()
            var useSoftware = false // decided once, then sticky

            while (isRunning) {
                val surface = activeSurface
                if (surface == null || !surface.isValid) {
                    try { Thread.sleep(16) } catch (_: InterruptedException) { break }
                    lastNs = System.nanoTime()
                    continue
                }

                val startNs = System.nanoTime()
                val dt = ((startNs - lastNs) / 1_000_000_000f).coerceIn(0.001f, 0.1f)
                lastNs = startNs

                var canvas: Canvas? = null
                try {
                    canvas = if (!useSoftware) {
                        try {
                            surface.lockHardwareCanvas()
                        } catch (e: Exception) {
                            Log.w("Mochi", "Hardware canvas failed, using software canvas", e)
                            useSoftware = true
                            surface.lockCanvas(null)
                        }
                    } else {
                        surface.lockCanvas(null)
                    }

                    if (canvas != null) {
                        renderer.draw(canvas, stableArea, currentState, smoothedLatG, smoothedLongG, dt)
                    }
                } catch (_: Exception) {
                    // surface torn down mid-frame
                } finally {
                    if (canvas != null) {
                        try { surface.unlockCanvasAndPost(canvas) } catch (_: Exception) {}
                    }
                }

                val sleepNs = frameNs - (System.nanoTime() - startNs)
                if (sleepNs > 0) {
                    try {
                        Thread.sleep(sleepNs / 1_000_000L, (sleepNs % 1_000_000L).toInt())
                    } catch (_: InterruptedException) { break }
                }
            }
        }
    }

    private fun stopRenderThread() {
        isRunning = false
        renderThread?.interrupt()
        try { renderThread?.join(400) } catch (_: InterruptedException) {}
        renderThread = null
    }

    // ---- Sensors ----

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null || event.sensor.type != activeSensor?.type) return
        val v = event.values

        val rawX: Float
        val rawForward: Float
        if (usingFallback) {
            if (!gravSeeded) {
                for (i in 0..2) grav[i] = v[i]
                gravSeeded = true
            } else {
                for (i in 0..2) grav[i] = 0.98f * grav[i] + 0.02f * v[i]
            }
            rawX = v[0] - grav[0]
            rawForward = if (isPhoneMountedUpright) -(v[2] - grav[2]) else (v[1] - grav[1])
        } else {
            rawX = v[0]
            rawForward = if (isPhoneMountedUpright) -v[2] else v[1]
        }

        // Low-pass filter (alpha = 0.15) against road/engine vibration
        smoothedLatG += filterAlpha * (rawX - smoothedLatG)
        smoothedLongG += filterAlpha * (rawForward - smoothedLongG)

        // Priority: braking > accelerating > turns > idle, with per-state hysteresis
        val lon = smoothedLongG
        val lat = smoothedLatG
        val s = currentState
        currentState = when {
            lon < enterBrake || (s == MochiState.BRAKING && lon < exitBrake) -> MochiState.BRAKING
            lon > enterAccel || (s == MochiState.ACCELERATING && lon > exitAccel) -> MochiState.ACCELERATING
            lat < -enterTurn || (s == MochiState.TURNING_LEFT && lat < -exitTurn) -> MochiState.TURNING_LEFT
            lat > enterTurn || (s == MochiState.TURNING_RIGHT && lat > exitTurn) -> MochiState.TURNING_RIGHT
            else -> MochiState.IDLE
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}

// ==========================================
// 3. MORPHING CANVAS RENDERER
// ==========================================

class MochiFaceRenderer {

    private val whiteFill = Paint().apply { color = Color.WHITE; isAntiAlias = true; style = Paint.Style.FILL }
    private val blackFill = Paint().apply { color = Color.BLACK; isAntiAlias = true; style = Paint.Style.FILL }
    private val whiteStroke = Paint().apply {
        color = Color.WHITE
        isAntiAlias = true
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val blushPaint = Paint().apply { color = Color.rgb(255, 120, 150); isAntiAlias = true }

    private val leftEyePath = Path()
    private val rightEyePath = Path()

    // Morph weights 0..1 (lookX is -1..1)
    private var shockWeight = 0f
    private var squintWeight = 0f
    private var lookXWeight = 0f

    private var currentTilt = 0f
    private var currentDepthScale = 1f
    private var currentDepthShiftY = 0f
    private var idleTick = 0f
    private var shakeTick = 0f

    private var isBlinking = false
    private var blinkTimerSec = 3.0f
    private var blinkProgressSec = 0f
    private val blinkDurationSec = 0.18f

    private fun ease(cur: Float, target: Float, rate: Float, dt: Float): Float =
        cur + (target - cur) * (1f - exp(-rate * dt))

    fun draw(
        canvas: Canvas,
        area: Rect,
        state: MochiState,
        latG: Float,
        longG: Float,
        dt: Float
    ) {
        val w = area.width().toFloat()
        val h = area.height().toFloat()
        if (w <= 0f || h <= 0f) return

        canvas.drawColor(Color.BLACK) // clear the whole surface, not just the face area

        val s = min(w, h) / 480f
        val cx = area.exactCenterX()
        val cy = area.exactCenterY()

        // Blink timer (randomized 2.5-5.5 s gap)
        if (!isBlinking) {
            blinkTimerSec -= dt
            if (blinkTimerSec <= 0f) { isBlinking = true; blinkProgressSec = 0f }
        } else {
            blinkProgressSec += dt
            if (blinkProgressSec >= blinkDurationSec) {
                isBlinking = false
                blinkTimerSec = 2.5f + Random.nextFloat() * 3.0f
            }
        }
        val blinkFactor = if (isBlinking && shockWeight < 0.2f && squintWeight < 0.2f)
            sin(PI.toFloat() * (blinkProgressSec / blinkDurationSec)).coerceIn(0f, 1f) else 0f

        // Targets
        val targetShock = if (state == MochiState.BRAKING) 1f else 0f
        val targetSquint = if (state == MochiState.ACCELERATING) 1f else 0f
        val targetLookX = when (state) {
            MochiState.TURNING_LEFT -> 1f    // look right
            MochiState.TURNING_RIGHT -> -1f  // look left
            else -> 0f
        }
        shockWeight = ease(shockWeight, targetShock, 14f, dt)
        squintWeight = ease(squintWeight, targetSquint, 14f, dt)
        lookXWeight = ease(lookXWeight, targetLookX, 10f, dt)

        // Lean back on acceleration = move down + shrink; tilt against the turn
        val accel = state == MochiState.ACCELERATING
        currentDepthScale = ease(currentDepthScale, if (accel) 0.92f else 1f, 8f, dt)
        currentDepthShiftY = ease(currentDepthShiftY, if (accel) 16f * s else 0f, 8f, dt)
        currentTilt = ease(currentTilt, (-latG * 2.2f).coerceIn(-12f, 12f), 8f, dt)

        // Idle bob + brake shiver (smooth sines, not random noise)
        idleTick += dt * 3.2f
        shakeTick += dt
        val bobY = sin(idleTick) * 4f * s
        var shakeX = 0f
        var shakeY = 0f
        if (shockWeight > 0.05f) {
            val mag = shockWeight * 8f * s
            shakeX = sin(shakeTick * 61f) * mag
            shakeY = sin(shakeTick * 47f + 1.3f) * mag * 0.6f
        }

        canvas.save()
        canvas.translate(cx + shakeX, cy + bobY + currentDepthShiftY + shakeY)
        canvas.rotate(currentTilt)
        canvas.scale(currentDepthScale, currentDepthScale)

        val eyeShiftX = (-latG * 5f * s).coerceIn(-35f * s, 35f * s)
        val eyeShiftY = (longG * 4f * s).coerceIn(-25f * s, 25f * s)
        val spacing = 85f * s
        val lx = -spacing + eyeShiftX
        val rx = spacing + eyeShiftX
        val ey = eyeShiftY

        // A: shock rings
        if (shockWeight > 0.01f) {
            whiteStroke.strokeWidth = 8f * s
            whiteStroke.alpha = (shockWeight * (1f - squintWeight) * 255).toInt().coerceIn(0, 255)
            canvas.drawCircle(lx, ey, 46f * s, whiteStroke)
            canvas.drawCircle(rx, ey, 46f * s, whiteStroke)
        }

        // B: round eyes (pupil-sized disc shrinks when shocked)
        val eyeAlpha = ((1f - squintWeight) * (1f - blinkFactor) * 255).toInt().coerceIn(0, 255)
        if (eyeAlpha > 0) {
            val r = (28f * (1f - shockWeight) + 11f * shockWeight) * s
            whiteFill.alpha = eyeAlpha
            canvas.drawCircle(lx, ey, r, whiteFill)
            canvas.drawCircle(rx, ey, r, whiteFill)

            // C: side-glance pupil dots
            if (abs(lookXWeight) > 0.02f && shockWeight < 0.6f) {
                val off = lookXWeight * 10f * s
                blackFill.alpha = (abs(lookXWeight) * (1f - shockWeight) * eyeAlpha).toInt().coerceIn(0, 255)
                canvas.drawCircle(lx + off, ey, 8f * s, blackFill)
                canvas.drawCircle(rx + off, ey, 8f * s, blackFill)
            }
        }

        // D: blink slits
        if (blinkFactor > 0.01f) {
            whiteStroke.strokeWidth = 9f * s
            whiteStroke.alpha = (blinkFactor * 255).toInt().coerceIn(0, 255)
            canvas.drawLine(lx - 25f * s, ey, lx + 25f * s, ey, whiteStroke)
            canvas.drawLine(rx - 25f * s, ey, rx + 25f * s, ey, whiteStroke)
        }

        // E: joyful "^ ^"
        if (squintWeight > 0.01f) {
            val ew = 30f * s
            val eh = 22f * s
            whiteStroke.strokeWidth = 10f * s
            whiteStroke.alpha = (squintWeight * 255).toInt().coerceIn(0, 255)

            leftEyePath.reset()
            leftEyePath.moveTo(lx - ew, ey + eh * 0.5f)
            leftEyePath.lineTo(lx, ey - eh * 0.5f)
            leftEyePath.lineTo(lx + ew, ey + eh * 0.5f)

            rightEyePath.reset()
            rightEyePath.moveTo(rx - ew, ey + eh * 0.5f)
            rightEyePath.lineTo(rx, ey - eh * 0.5f)
            rightEyePath.lineTo(rx + ew, ey + eh * 0.5f)

            canvas.drawPath(leftEyePath, whiteStroke)
            canvas.drawPath(rightEyePath, whiteStroke)
        }

        // Cheeks
        blushPaint.alpha = ((1f - shockWeight * 0.4f) * 255).toInt().coerceIn(0, 255)
        canvas.drawCircle(lx - 35f * s, ey + 38f * s, 14f * s, blushPaint)
        canvas.drawCircle(rx + 35f * s, ey + 38f * s, 14f * s, blushPaint)

        canvas.restore()
    }
}
